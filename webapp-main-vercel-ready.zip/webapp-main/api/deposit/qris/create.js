const { readJson } = require('../../../lib/readJson');
const { callPakkasirCreate, normalizeCreateResponse, makeReference } = require('../../../lib/pakkasir');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const body = await readJson(req);
    const totalNum = parseInt(body.total, 10);

    if (!Number.isFinite(totalNum) || totalNum <= 0) {
      return res.status(400).json({ message: 'total tidak valid' });
    }

    const reference = makeReference('DEP');
    const callbackUrl = process.env.PAKKASIR_CALLBACK_URL || '';

    const upstream = await callPakkasirCreate({ total: totalNum, reference, callbackUrl });

    if (upstream.ok) {
      const normalized = normalizeCreateResponse(upstream.data, reference);
      return res.status(200).json({
        provider: 'Pakkasir',
        ...normalized,
        message: 'QRIS berhasil dibuat'
      });
    }

    // UI fallback: still return reference so user can test flow.
    return res.status(200).json({
      provider: 'Pakkasir',
      reference,
      qrisContent: null,
      qrImage: null,
      qrUrl: null,
      expiresIn: 300,
      message: `QRIS mock dibuat (perlu konfigurasi endpoint). Detail: ${upstream.error}`
    });
  } catch (e) {
    return res.status(500).json({ message: e.message || 'server error' });
  }
};
