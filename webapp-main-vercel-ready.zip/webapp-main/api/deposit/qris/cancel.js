const { readJson } = require('../../../lib/readJson');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  // Best-effort cancel. Provider cancel endpoint is not standardized.
  await readJson(req);
  return res.status(200).json({ ok: true });
};
