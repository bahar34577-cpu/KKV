const { readJson } = require('../../../lib/readJson');
const { callPakkasirStatus, normalizeStatusResponse } = require('../../../lib/pakkasir');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const body = await readJson(req);
    const reference = body.reference;
    if (!reference) return res.status(400).json({ message: 'reference wajib' });

    const upstream = await callPakkasirStatus({ reference });
    if (upstream.ok) {
      const normalized = normalizeStatusResponse(upstream.data);
      return res.status(200).json(normalized);
    }

    return res.status(200).json({ status: 'pending', paid: false, message: `Status mock (perlu konfigurasi). Detail: ${upstream.error}` });
  } catch (e) {
    return res.status(500).json({ message: e.message || 'server error' });
  }
};
