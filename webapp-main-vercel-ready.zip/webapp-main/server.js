/*
  Simple proxy server for QRIS (recommended so API key stays server-side).

  How it works:
  - Frontend calls:
      POST /api/deposit/qris/create
      POST /api/deposit/qris/status
      POST /api/deposit/qris/cancel
  - This server forwards requests to your Pakkasir QRIS API.

  IMPORTANT:
  - Because provider endpoints vary, adjust PAKKASIR_BASE_URL + paths below
    to match the documentation you got from Pakkasir.
*/

const express = require('express');
const path = require('path');
const crypto = require('crypto');

// Node 18+ has global fetch. For older Node versions, lazy-load node-fetch.
const fetchFn = global.fetch
  ? global.fetch.bind(global)
  : (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

require('dotenv').config();

const app = express();
app.use(express.json({ limit: '1mb' }));

// Serve static webapp
app.use(express.static(path.join(__dirname)));

const PORT = process.env.PORT || 3000;

const PAKKASIR_API_KEY = process.env.PAKKASIR_API_KEY || '';
const PAKKASIR_BASE_URL = (process.env.PAKKASIR_BASE_URL || '').replace(/\/+$/, '');

// In-memory order store (demo). For production use Redis/DB.
const pending = new Map();

function nowIsoJakarta() {
  // ISO-ish timestamp with +07:00 offset
  const d = new Date(Date.now() + 7 * 60 * 60 * 1000);
  // Convert to YYYY-MM-DDTHH:mm:ss+07:00
  const iso = d.toISOString().replace('Z', '');
  return iso.substring(0, 19) + '+07:00';
}

function pickFirst(obj, keys) {
  for (const k of keys) {
    if (!obj) continue;
    const v = obj[k];
    if (v !== undefined && v !== null && v !== '') return v;
  }
  return null;
}

async function tryJson(res) {
  const text = await res.text();
  if (!text) return null;
  try { return JSON.parse(text); } catch { return { raw: text }; }
}

async function callPakkasirCreate({ total, reference, callbackUrl }) {
  if (!PAKKASIR_BASE_URL || !PAKKASIR_API_KEY) {
    return { ok: false, error: 'PAKKASIR_BASE_URL / PAKKASIR_API_KEY belum diset' };
  }

  // Common patterns: adjust if your provider differs
  const candidates = [
    { method: 'POST', path: '/qris/create' },
    { method: 'POST', path: '/api/qris/create' },
    { method: 'POST', path: '/qris' }
  ];

  const body = {
    amount: total,
    nominal: total,
    total: total,
    reference,
    external_id: reference,
    partnerReferenceNo: reference,
    description: `Deposit ${reference}`,
    callback_url: callbackUrl,
    callbackUrl: callbackUrl,
    expires_in: 300
  };

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${PAKKASIR_API_KEY}`,
    'x-api-key': PAKKASIR_API_KEY
  };

  let lastErr = null;
  for (const c of candidates) {
    const url = `${PAKKASIR_BASE_URL}${c.path}`;
    try {
      const res = await fetchFn(url, { method: c.method, headers, body: JSON.stringify(body) });
      const data = await tryJson(res);
      if (res.ok) {
        return { ok: true, data };
      }
      lastErr = new Error(`${res.status} ${res.statusText} ${JSON.stringify(data)}`);
    } catch (e) {
      lastErr = e;
    }
  }
  return { ok: false, error: lastErr ? lastErr.message : 'Create QRIS failed' };
}

async function callPakkasirStatus({ reference }) {
  if (!PAKKASIR_BASE_URL || !PAKKASIR_API_KEY) {
    return { ok: false, error: 'PAKKASIR_BASE_URL / PAKKASIR_API_KEY belum diset' };
  }

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${PAKKASIR_API_KEY}`,
    'x-api-key': PAKKASIR_API_KEY
  };

  const candidates = [
    { method: 'POST', path: '/qris/status', body: { reference, id: reference, invoice_id: reference } },
    { method: 'POST', path: '/api/qris/status', body: { reference, id: reference, invoice_id: reference } },
    { method: 'GET', path: `/qris/status?reference=${encodeURIComponent(reference)}` },
    { method: 'GET', path: `/api/qris/status?reference=${encodeURIComponent(reference)}` }
  ];

  let lastErr = null;
  for (const c of candidates) {
    const url = `${PAKKASIR_BASE_URL}${c.path}`;
    try {
      const res = await fetchFn(url, {
        method: c.method,
        headers,
        body: c.method === 'GET' ? undefined : JSON.stringify(c.body)
      });
      const data = await tryJson(res);
      if (res.ok) {
        return { ok: true, data };
      }
      lastErr = new Error(`${res.status} ${res.statusText} ${JSON.stringify(data)}`);
    } catch (e) {
      lastErr = e;
    }
  }
  return { ok: false, error: lastErr ? lastErr.message : 'Status QRIS failed' };
}

function normalizeCreateResponse(data, reference) {
  // Try to extract QR payload from various provider response shapes
  const root = data && data.data ? data.data : data;

  const qrisContent = pickFirst(root, [
    'qris_content', 'qrisContent', 'qr_string', 'qrString', 'qrContent', 'qris', 'payload'
  ]) || pickFirst(data, ['qris_content', 'qrisContent', 'qr_string', 'qrString', 'qrContent']);

  const qrImage = pickFirst(root, ['qr_image', 'qrImage', 'qris_image', 'qrisImage']);
  const qrUrl = pickFirst(root, ['qr_url', 'qrUrl', 'qris_url', 'qrisUrl', 'checkout_url', 'checkoutUrl']);
  const expirySeconds = parseInt(pickFirst(root, ['expires_in', 'expiresIn', 'expirySeconds', 'expiry']) || '300', 10);

  const ref = pickFirst(root, ['reference', 'referenceNo', 'partnerReferenceNo', 'external_id', 'id', 'invoice_id', 'invoiceId']) || reference;

  return {
    reference: ref,
    qrisContent,
    qrImage,
    qrUrl,
    expiresIn: Number.isFinite(expirySeconds) ? expirySeconds : 300
  };
}

function normalizeStatusResponse(data) {
  const root = data && data.data ? data.data : data;
  const status = (pickFirst(root, ['status', 'payment_status', 'paymentStatus', 'state']) || pickFirst(data, ['status', 'payment_status', 'paymentStatus']) || 'pending');
  const paid = !!(root && (root.paid === true || root.isPaid === true));
  return { status, paid };
}

// Create QRIS
app.post('/api/deposit/qris/create', async (req, res) => {
  try {
    const { total } = req.body || {};
    const totalNum = parseInt(total, 10);
    if (!Number.isFinite(totalNum) || totalNum <= 0) {
      return res.status(400).json({ message: 'total tidak valid' });
    }

    const reference = `DEP${Date.now().toString().slice(-8)}`;
    const callbackUrl = process.env.PAKKASIR_CALLBACK_URL || '';

    const upstream = await callPakkasirCreate({ total: totalNum, reference, callbackUrl });

    if (upstream.ok) {
      const normalized = normalizeCreateResponse(upstream.data, reference);
      pending.set(normalized.reference, {
        total: totalNum,
        createdAt: Date.now(),
        status: 'pending'
      });
      return res.json({
        provider: 'Pakkasir',
        ...normalized,
        message: 'QRIS berhasil dibuat'
      });
    }

    // Fallback mock (so UI still works while you adjust endpoints)
    pending.set(reference, { total: totalNum, createdAt: Date.now(), status: 'pending' });
    return res.json({
      provider: 'Pakkasir',
      reference,
      qrisContent: null,
      qrImage: null,
      qrUrl: null,
      expiresIn: 300,
      message: `QRIS mock dibuat (perlu konfigurasi endpoint). Detail: ${upstream.error}`
    });
  } catch (e) {
    return res.status(500).json({ message: e.message || 'server error' });
  }
});

// Check status
app.post('/api/deposit/qris/status', async (req, res) => {
  try {
    const { reference } = req.body || {};
    if (!reference) return res.status(400).json({ message: 'reference wajib' });

    const upstream = await callPakkasirStatus({ reference });
    if (upstream.ok) {
      const normalized = normalizeStatusResponse(upstream.data);
      const local = pending.get(reference);
      if (local) {
        local.status = normalized.status;
        pending.set(reference, local);
      }
      return res.json(normalized);
    }

    // Fallback: if not configured, keep pending
    return res.json({ status: 'pending', paid: false, message: `Status mock (perlu konfigurasi). Detail: ${upstream.error}` });
  } catch (e) {
    return res.status(500).json({ message: e.message || 'server error' });
  }
});

// Cancel (best effort)
app.post('/api/deposit/qris/cancel', async (req, res) => {
  const { reference } = req.body || {};
  if (reference) pending.delete(reference);
  return res.json({ ok: true });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Webapp running on http://localhost:${PORT}`);
  if (!PAKKASIR_BASE_URL || !PAKKASIR_API_KEY) {
    console.log('[INFO] Set PAKKASIR_BASE_URL dan PAKKASIR_API_KEY di .env untuk mode LIVE.');
  }
});
